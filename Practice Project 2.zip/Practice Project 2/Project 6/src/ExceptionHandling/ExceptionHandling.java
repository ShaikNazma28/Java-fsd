package ExceptionHandling;

import java.util.Scanner;

public class ExceptionHandling {
	

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        try {
	            System.out.print("Enter a number: ");
	            int number = Integer.parseInt(scanner.nextLine());

	            if (number < 0) {
	                throw new CustomException("Number cannot be negative");
	            }

	            System.out.println("You entered: " + number);
	        } catch (NumberFormatException e) {
	            System.out.println("Invalid input. Please enter a valid number.");
	        } catch (CustomException e) {
	            System.out.println(e.getMessage());
	        } finally {
	            scanner.close();
	            System.out.println("Scanner closed.");
	        }
	    }
	}

	@SuppressWarnings("serial")
	class CustomException extends Exception {
	    public CustomException(String message) {
	        super(message);
	    }
	}
