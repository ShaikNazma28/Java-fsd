/**
 * 
 */
/**
 * 
 */
module objectoriented {
}