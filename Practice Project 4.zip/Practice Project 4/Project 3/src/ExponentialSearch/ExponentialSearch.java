package ExponentialSearch;

public class ExponentialSearch {

	    public static int exponentialSearch(int[] arr, int target) {
	        if (arr[0] == target) {
	            return 0; // Return 0 if the target is found at the first element
	        }

	        int i = 1;
	        while (i < arr.length && arr[i] <= target) {
	            i *= 2;
	        }

	        return binarySearch(arr, i / 2, Math.min(i, arr.length - 1), target);
	    }

	    public static int binarySearch(int[] arr, int left, int right, int target) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target) {
	                return mid; // Return the index where the target is found
	            }

	            if (arr[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; // Return -1 if target is not found in the array
	    }

	    public static void main(String[] args) {
	        int[] arr = {1, 3, 6, 8, 12, 15, 18, 24, 42};
	        int target = 12;

	        int result = exponentialSearch(arr, target);

	        if (result != -1) {
	            System.out.println("Element found at index " + result);
	        } else {
	            System.out.println("Element not found in the array");
	        }
	    }
	}

